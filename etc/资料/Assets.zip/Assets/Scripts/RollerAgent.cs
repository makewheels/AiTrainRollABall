﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;

public class RollerAgent : Agent
{

    //目标坐标
    public Transform target;

    public float speed = 10;

    Rigidbody rBody;

    // Start is called before the first frame update
    void Start()
    {
        rBody = GetComponent<Rigidbody>();
    }



    //进入新的一轮时调用的函数
    public override void OnEpisodeBegin()
    {


        //只有当小球掉落的时候，才去重置小球的位置（目的是让狗子一直可以吃到小球）
        if (this.transform.position.y < 0)
        {
            //重新开始，设置小球的初始位置
            this.transform.position = new Vector3(0, 0.5f, 0);
            //速度与旋转
            this.rBody.velocity = Vector3.zero;
            this.rBody.angularVelocity = Vector3.zero;
        }
        

        //随机Target的位置
        target.position = new Vector3(Random.value * 8 - 4, 0.5f, Random.value * 8 - 4);
    }


    //收集观察的结果
    public override void CollectObservations(VectorSensor sensor)
    {
        //一共观察了8个float值

        //2个坐标（当前位置的坐标，Target的最表）(x,y,z)(x,y,z)
        sensor.AddObservation(target.position);
        sensor.AddObservation(this.transform.position);
        //2个速度（x与z的速度）
        sensor.AddObservation(rBody.velocity.x);
        sensor.AddObservation(rBody.velocity.z);

    }
    //可列

    //接收动作，是否给予奖励
    public override void OnActionReceived(float[] vectorAction)
    {
        //print("Horizontal" + vectorAction[0]);
        //print("Vertical" + vectorAction[1]);
        //拿到水平和垂直的方向
        Vector3 control = Vector3.zero;
        control.x = vectorAction[0];
        control.z = vectorAction[1];
        //移动小球
        rBody.AddForce(control * speed);

        //狗子出界了，使用y去判断
        if (this.transform.position.y < 0)
        {
            //结束这一轮的测试
            EndEpisode();
        }

        //狗子吃到东西了
        float distance = Vector3.Distance(this.transform.position, target.position);
        if (distance < 1.41f)
        {
            //给定奖励
            SetReward(1.0f);
            EndEpisode();
        }


    }


    //手动操作智能体
    public override void Heuristic(float[] actionsOut)
    {   
        //拿到水平和垂直方向
        actionsOut[0] = Input.GetAxis("Horizontal");
        actionsOut[1] = Input.GetAxis("Vertical");
    }


}
